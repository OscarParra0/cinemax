/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Oscar Ivan Parra Florian
 */
public class Silla {
    private int precio;
    private boolean esPreferencial;
    private Cliente cliente;
    
    
    public Silla(){
        this.precio = 0;
    }
    
    public Silla(int precio, boolean esPreferencial){
        this.precio = precio;
        this.esPreferencial = esPreferencial;
        this.cliente = new Cliente();
    }
    
    public int getPrecio() {
        return precio;
    }
    
    public void setPrecio(int precio) {
        this.precio = precio;
    }
    
    public boolean getEsPreferencial() {
        return esPreferencial;
    }
    
    public void setEsPreferencial(boolean esPreferencial) {
        this.esPreferencial = esPreferencial;
    }
    
    public Cliente getCliente() {
        return cliente;
    }
    
    public void setCliente( Cliente cliente ) {
        this.cliente = cliente;
    }
    
    
}
