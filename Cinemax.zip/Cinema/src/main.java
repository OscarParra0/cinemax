
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author Oscar Ivan Parra Florian
 */
public class main {

    public static void main(String[] args) {
        
        //Definición de variables
        Scanner scanner = new Scanner(System.in);
        Sala sala = new Sala();
        sala.Inicializar();
        
        int opc = 4;
        int fila = 0;
        int columna = 0;
        int opcOcupante = 0;
        
        while(opc != 3){
            
            while(opc == 4){
                
                System.out.println("-------------------------------");

                System.out.println("Bienvenido a su sistema CINE, por favor seleccione una opción: \n");

                System.out.println("1. Reservar");
                System.out.println("2. Visualizar Sillas");
                System.out.println("3. Cerrar y salir");

                System.out.println();

                opc = scanner.nextInt();

                System.out.println("-------------------------------");
                
            }

            while(opc == 1){
                Cliente cliente = new Cliente();
                System.out.println("Ingrese su identificacion: ");
                cliente.setId(scanner.nextInt()); //Para numero

                System.out.println("Ingrese su nombre: ");
                cliente.setNombre(scanner.next()); //Para texto

                System.out.println("Ingrese su correo: ");
                cliente.setCorreo(scanner.next()); //Para texto

                System.out.println("Ingrese su telefono: ");
                cliente.setTelefono(scanner.next()); //Para texto

                sala.Imprimir();

                System.out.println("Ingrese la fila en la que desea su silla: ");
                fila = scanner.nextInt();

                System.out.println("Ingrese la columna en la que desea su silla: ");
                columna = scanner.nextInt();

                try{
                    
                    if(sala.teatro[fila][columna].getCliente().getId() == 0){

                        System.out.println("-------------------------------");
                        
                        System.out.println("El precio de la silla es de: $ " + sala.teatro[fila][columna].getPrecio());
                        System.out.println("Presione 1 si el cliente esta de acuerdo");

                        int opcAceptar = scanner.nextInt();

                        if(opcAceptar == 1){

                            sala.teatro[fila][columna].setCliente(cliente);

                        }

                    } else if(sala.teatro[fila][columna].getCliente().getId() != 0){

                        System.out.println("Silla ya ocupada");

                    }
                    
                } catch (IndexOutOfBoundsException error) {
                    
                    System.out.println("Esta silla no existe. Intentelo nuevamente \n");   
                }
                
                System.out.println("-------------------------------");

                System.out.println("Transacción finalizada.");
                System.out.println("¿Continuar? \n");

                System.out.println("1. Nueva reserva");
                System.out.println("2. Visualizar sillas");
                System.out.println("3. Cerrar y salir");
                System.out.println("4. Volver al menu principal");

                opc = scanner.nextInt();
                
                System.out.println("-------------------------------");

            }
            
            while(opc == 2){
                sala.Imprimir();
                
                System.out.println("¿Desea examinar el ocupante de alguna silla? \n");
                System.out.println("(1)Si");
                System.out.println("(2)No");
                
                opcOcupante = scanner.nextInt();
                
                while(opcOcupante == 1){
                    
                    System.out.println("Ingrese la fila");
                    fila = scanner.nextInt();

                    System.out.println("Ingrese la columna");
                    columna = scanner.nextInt();
                    
                    try{
                        if(sala.teatro[fila][columna].getCliente().getId() == 0){
                            System.out.println("No se ha encontrado reserva. Intentelo nuevamente");

                        } else {
                            sala.teatro[fila][columna].getCliente().Imprimir();
                        }
                    } catch(IndexOutOfBoundsException error){
                        System.out.println("Esta silla no existe. Intentelo nuevamente \n");   
                    }
                    
                    System.out.println("-------------------------------");

                    System.out.println("Transaccion finalizada.");
                    System.out.println("¿Desea continuar?");
                    System.out.println("1. Si, consultar otra silla");
                    System.out.println("2. No");
                    
                    opcOcupante = scanner.nextInt();

                }
                
                System.out.println("Transacción finalizada.");
                System.out.println("¿Continuar? \n");

                System.out.println("1. Comenzar nueva reserva");
                System.out.println("2. Visualizar sillas");
                System.out.println("3. Cerrar y salir");
                System.out.println("4. Volver al menu principal");

                opc = scanner.nextInt();

                

            }
        }
             
             
                 
    }

    
}
