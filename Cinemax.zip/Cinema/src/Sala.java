/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Oscar Ivan Parra Florian
 */
public class Sala {
    
    public Silla[][] teatro;
    
    public Sala(){
        teatro = new Silla[10][5];
    }
    
    public void Inicializar(){
        for(int fila = 0; fila < teatro.length; fila++){
            for(int columna = 0; columna < teatro[0].length; columna++){
                
                int precio = 0;
                boolean esPreferencial = false;
                
                if(fila < 3){
                    precio = 5000;
                } else if(fila < teatro.length - 1){
                    precio = 10000;
                } else {
                    precio = 15000;
                    esPreferencial = true;
                }
                
                Silla silla = new Silla(precio, esPreferencial);
                this.teatro[fila][columna] = silla;
                
            }
        
        }
    }
        
    
    
    public void Imprimir(){
        
        System.out.println("---------------------------------"); //PRINLN imprime y luego hace un salto de linea
        System.out.println("    P A N T A L L A \n"); //Al escribir \n dentro de un PRINT o PRINTLN, se hace un salto de linea

               
        System.out.print("        "); //PRINT imprime pero NO hace un salto de linea
        
        
        for(int columna = 0; columna < teatro[0].length; columna++){ //Ciclo para imprimir el numero de la columna
            System.out.print(columna + " "); 
        }
        System.out.println("\n");

        
        for(int fila = 0; fila < teatro.length; fila++){ 
            
            System.out.print(fila + "       "); //Ciclo para imprimjr el numero de la fila
            
            for(int columna = 0; columna < teatro[0].length; columna++){ //Ciclo para imprimir todos los asientos 
                
                if(teatro[fila][columna].getCliente().getId() != 0){
                    System.out.print("1 ");
                } else {
                    System.out.print("0 ");
                }
            }
            System.out.println();
        }   
         
        
        System.out.println("---------------------------------");

        
        
        //Validaciones = Aparezca el mensaje si la silla NO existe
        //Seleccione ubicación, pida datos = El usuario del sistema puede seleccionar una opcion para NO comprar una silla, pero sí para recibir los datos de la persona que la ocupa. 
    }
}