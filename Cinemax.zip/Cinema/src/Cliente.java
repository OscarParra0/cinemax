/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Oscar Ivan Parra Florian
 */

// Declaración de la clase 
public class Cliente {
    private int id;
    private String nombre;
    private String correo;
    private String telefono;
    
    
    //Constructor por defecto (Al crear el objeto, los parametros se dejan 
    //nulos excepto el id, el cual se deja en 0)
    public Cliente(){
        this.id = 0;
    }
    
    //Constructor que puede utilizarse para definir de una vez al cliente
    //(puede crearse tantos constructores como se prefiera)
    public Cliente(int id, String nombre ,String correo, String telefono){
        this.id = id;
        this.nombre = nombre;
        this.correo = correo;
        this.telefono = telefono;
    }
    
    //De aquí en adelante se definen los metodos Get y Set de cada atributo,
    //debido a que los atributos son de alcance PRIVADO, no es posible 
    //asignarlos directamente
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getCorreo() {
        return correo;
    }
    
    public void setCorreo( String correo ) {
        this.correo = correo;
    }
    
    public String getTelefono() {
        return telefono;
    }
    
    public void setTelefono( String telefono ) {
        this.telefono = telefono;
    }
    
    public void Imprimir(){
        System.out.println("ID: " + this.id);
        System.out.println("Nombre: " + this.nombre);
        System.out.println("Correo: " + this.correo);
        System.out.println("Telefono: " + this.telefono);

    }
}

